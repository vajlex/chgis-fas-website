README  China Dams 2013

SOURCE:  Global Reservoir and Dam (GRanD) database [Version 1.1] 2011

SOURCE URL:   http://sedac.ciesin.columbia.edu/data/set/grand-v1-dams-rev01

CITATION:  Lehner, B., C. Reidy Liermann, C. Revenga, C. Vorosmarty, B. Fekete, P. Crouzet, P. Doll, M. Endejan, K. Frenken, J. Magome, C. Nilsson, J.C. Robertson, R. Rodel, N. Sindorf, and D. Wisser. 2011. Global Reservoir and Dam Database, Version 1 (GRanDv1) Dams, revision 01.  Palisades, NY: SEDAC.

DESCRIPTION:

This dataset is a subset of the Global Dams and Reservoirs data, totalling 773 Dam features as points, out of a global dataset of 6,000 features.   The China features were extracted and joined with their parent counties from the 2000 Census.

In the current version of the dataset, published on ChinaMap in 2013, approximately 200 of the dam names have been verified and entered in Chinese Characters, while the remaining dam names are only available in English.   We hope to provide a more complete version including all the Chinese names at some time in the future.

The dataset has been edited for browsing online using ChinaMap.   To obtain the full version of the data, see the publication URL above.

Edited By:  Lex Berman



